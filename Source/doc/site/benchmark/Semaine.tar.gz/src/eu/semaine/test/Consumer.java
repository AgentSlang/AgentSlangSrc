package eu.semaine.test;

import eu.semaine.components.Component;
import eu.semaine.jms.message.SEMAINEMessage;
import eu.semaine.jms.receiver.Receiver;

import javax.jms.JMSException;

/**
 * @author Ovidiu Serban, ovidiu@roboslang.org
 * @version 1, 2/20/13
 */
public class Consumer extends Component {
    private long timestamp;
    private double avg;
    private int size;
    private boolean started;
    private String label;

    public Consumer() throws JMSException {
        super("MyConsumer");

        receivers.add(new Receiver("test.topic"));

        timestamp = -1;
        avg = 0;
        size = 0;
        started = false;
    }

    protected void react(SEMAINEMessage message) throws Exception {
        String stringData = message.getText();

        if (started) {
            size++;
            avg = ((size - 1) * avg + (System.nanoTime() - timestamp)) / size;
            started = false;
        } else {
            if (stringData.equals("start")) {
                timestamp = System.nanoTime();
                started = true;
            } else if (stringData.startsWith("begin")) {
                timestamp = -1;
                avg = 0;
                size = 0;
                started = false;
                label = stringData.substring(stringData.indexOf('=') + 1);
            } else if (stringData.equals("end")) {
                started = false;
                System.out.printf("[%s] Avg=%f%n", label, (avg / 1000000));
            }
        }
    }
}
