package test;

public class Sender {
    public static void main(String[] args) {
        Producer producer = new Producer();
        Consumer consumer = new Consumer();
    }
}