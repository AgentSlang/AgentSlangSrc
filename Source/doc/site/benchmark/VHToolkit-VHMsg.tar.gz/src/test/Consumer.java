package test;

import edu.usc.ict.vhmsg.MessageEvent;
import edu.usc.ict.vhmsg.MessageListener;
import edu.usc.ict.vhmsg.VHMsg;

/**
 * @author Ovidiu Serban, ovidiu@roboslang.org
 * @version 1, 2/20/13
 */
public class Consumer implements MessageListener {
    private long timestamp;
    private double avg;
    private int size;
    private boolean started;
    private String label;
    private String topic = "testTopic";
    private VHMsg vhmsg;

    public Consumer() {
        timestamp = -1;
        avg = 0;
        size = 0;
        started = false;

        vhmsg = new VHMsg();

        boolean ret = vhmsg.openConnection();
        if (!ret) {
            System.out.println("Connection error!");
            return;
        }

        vhmsg.enableImmediateMethod();
        vhmsg.addMessageListener(this);
        vhmsg.subscribeMessage(topic);
    }

    public void messageAction(MessageEvent messageEvent) {
        String stringData = messageEvent.getMap().get(topic).toString();

        if (started) {
            size++;
            avg = ((size - 1) * avg + (System.nanoTime() - timestamp)) / size;
            started = false;
        } else {
            if (stringData.equals("start")) {
                timestamp = System.nanoTime();
                started = true;
            } else if (stringData.startsWith("begin")) {
                timestamp = -1;
                avg = 0;
                size = 0;
                started = false;
                label = stringData.substring(stringData.indexOf('=') + 1);
            } else if (stringData.equals("end")) {
                started = false;
                System.out.printf("[%s] Avg=%f%n", label, (avg / 1000000));
            }
        }
    }
}
