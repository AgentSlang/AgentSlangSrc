package test;

import edu.usc.ict.vhmsg.VHMsg;

import java.util.Arrays;
import java.util.Collection;
import java.util.Random;

/**
 * @author Ovidiu Serban, ovidiu@roboslang.org
 * @version 1, 2/20/13
 */
public class Producer {
    private static final Collection<Integer> MSG_SIZE = Arrays.asList(10, 100, 1000, 10000, 100000, 1000000);
    private static final int MSG_ITERATIONS = 100;
    private VHMsg sender;
    private Random random = new Random();

    public Producer() {
        sender = new VHMsg();
        boolean ret = sender.openConnection();
        if (!ret) {
            System.out.println("Connection error!");
            return;
        }

        Thread thread = new Thread() {
            public void run() {
                try {
                    Thread.sleep(5000);
                } catch (InterruptedException e) {
                    //-- ignore
                }

                for (int msgSize : MSG_SIZE) {
                    publishData("begin=" + msgSize);
                    for (int pass = 0; pass < MSG_ITERATIONS; pass++) {
                        String generatedMessage = buildMessage(msgSize);
                        publishData("start");
                        publishData(generatedMessage);
                        try {
                            Thread.sleep(100);
                        } catch (InterruptedException e) {
                            //-- ignore
                        }
                    }
                    publishData("end");
                }
            }
        };
        thread.start();
    }

    private String buildMessage(int size) {
        StringBuilder sb = new StringBuilder();

        for (int i = 0; i < size; i++) {
            sb.append("" + random.nextInt(10));
        }

        return sb.toString();
    }

    private void publishData(String data) {
        sender.sendMessage("testTopic", data);
    }
}
